//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DWinqouW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-B8XelsKF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B8XelsKF.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-sPS4ya04.js"]
	}
} });
//#endregion
export { tsrStartManifest };
