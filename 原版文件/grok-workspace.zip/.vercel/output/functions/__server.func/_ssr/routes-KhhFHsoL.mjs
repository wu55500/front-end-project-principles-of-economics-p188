import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, c as CircleHelp, i as Presentation, l as Check, n as Settings2, o as Pause, r as RotateCcw, s as Download, u as ArrowUp } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as Line, c as Bar, i as XAxis, l as ResponsiveContainer, n as LineChart, o as CartesianGrid, r as YAxis, s as ReferenceLine, t as BarChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-KhhFHsoL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[10px] text-sm font-medium transition-[opacity,transform,background-color,border-color] duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			outline: "border border-line-strong bg-transparent text-fg hover:bg-surface-2",
			ghost: "text-muted hover:text-fg hover:bg-surface-2",
			gain: "bg-gain/15 text-gain border border-gain/30 hover:bg-gain/25",
			loss: "bg-loss/15 text-loss border border-loss/30 hover:bg-loss/25"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-[13px]",
			icon: "size-11",
			iconSm: "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var SECTIONS = [
	{
		id: "story",
		label: "故事",
		no: "01"
	},
	{
		id: "chart",
		label: "画图",
		no: "02"
	},
	{
		id: "welfare",
		label: "选择",
		no: "03"
	},
	{
		id: "quiz",
		label: "测验",
		no: "04"
	},
	{
		id: "final",
		label: "结论",
		no: "05"
	}
];
var FLOW_CAPTIONS = {
	accept: "资金流循环：NL 纳税人 → NL 政府 → NL 纺织厂 →（低价出口）→ IS 消费者 →（付款回流）。第一笔钱来自 Neighborland 的纳税人。",
	tariff: "Isoland 筑起关税墙：出口包裹在边境被拦截，补贴流被切断；消费者把关税交给本国政府。价格回到 P₁，谁也没占到便宜。"
};
var QUIZ = [
	{
		q: "NL 政府补贴纺织厂的钱，最终来自谁？",
		opts: [
			"Isoland 的纺织厂",
			"Neighborland 的纳税人",
			"Isoland 的消费者"
		],
		ans: 1,
		exp: "补贴是政府支出，政府的钱来自本国（NL）税收——NL 纳税人在为 IS 消费者的低价布买单。"
	},
	{
		q: "t = 20 时，Isoland 的净福利变化是多少？",
		opts: [
			"−400",
			"0",
			"+800"
		],
		ans: 2,
		exp: "消费者剩余 +1,400，生产者剩余 −600，合计 +800（= 20t + t²）。"
	},
	{
		q: "面对 NL 的出口补贴，福利分析给 IS 的最优建议是？",
		opts: [
			"禁止进口",
			"说声谢谢，继续买",
			"立即征收报复关税"
		],
		ans: 1,
		exp: "接受净 +800，关税净 0，禁止净 −100。「谢谢」是最贵也最不客气的客气。"
	}
];
var SCRIPT = `【不公平竞争论 · 讲解逐字稿】
NL 政府对纺织品出口补贴，钱来自 NL 纳税人。补贴让 NL 工厂敢把价格压到 P₂ = 60 − t，低价涌入 IS。
对 IS 的账：消费者剩余 +t(120+t)/2（t=20 时 +1,400），生产者剩余 −t(80−t)/2（−600），净福利 = 20t + t² = +800，恒为正。
三种回应：接受补贴净 +800；报复关税把价格抬回 P₁，政府收 400、无谓损失 400，净效应为 0；禁止进口回到自给自足，工厂 +450、消费者 −550，净 −100。
结论：当邻居执意补贴你买东西时，最好的回应是说声谢谢。`;
var KEYBOARD = [
	{
		keys: ["P"],
		label: "演示模式"
	},
	{
		keys: ["`"],
		label: "工程解剖"
	},
	{
		keys: ["?"],
		label: "快捷键"
	},
	{
		keys: ["Space"],
		label: "暂停资金流"
	},
	{
		keys: ["R"],
		label: "重播资金流"
	},
	{
		keys: ["1–5"],
		label: "跳转章节"
	},
	{
		keys: ["←", "→"],
		label: "演示翻页"
	},
	{
		keys: ["Esc"],
		label: "退出演示"
	}
];
function clamp(v, lo, hi) {
	return Math.min(hi, Math.max(lo, v));
}
function demandQ(p) {
	return 120 - p;
}
function supplyQ(p) {
	return p - 20;
}
function calc(tRaw) {
	const t = clamp(tRaw, 0, 30);
	const p2 = 60 - t;
	const qd2 = demandQ(p2);
	const qs2 = supplyQ(p2);
	const cs = t * (120 + t) / 2;
	const ps = -(t * (80 - t)) / 2 + 0;
	return {
		t,
		p1: 60,
		p2,
		qd1: demandQ(60),
		qs1: supplyQ(60),
		qd2,
		qs2,
		imports: qd2 - qs2,
		cs,
		ps,
		net: cs + ps
	};
}
function scenarios(tRaw) {
	const t = clamp(tRaw, 0, 30);
	const m = calc(t);
	return {
		accept: {
			key: "accept",
			name: "接受补贴",
			consumer: m.cs,
			producer: m.ps,
			government: 0,
			dwl: 0,
			net: 20 * t + t * t
		},
		tariff: {
			key: "tariff",
			name: "报复关税",
			consumer: 0,
			producer: 0,
			government: 20 * t,
			dwl: -t * t,
			net: 20 * t - t * t
		},
		ban: {
			key: "ban",
			name: "禁止进口",
			consumer: -550,
			producer: 450,
			government: 0,
			dwl: 0,
			net: -100
		}
	};
}
function netCurve(steps = 31) {
	const xs = [];
	for (let i = 0; i < steps; i++) xs.push(30 * i / (steps - 1));
	return {
		xs,
		accept: xs.map((t) => 20 * t + t * t),
		tariff: xs.map((t) => 20 * t - t * t)
	};
}
function fmt(n) {
	return Math.round(n).toLocaleString("en-US");
}
function fmtSigned(n) {
	return (n >= 0 ? "+" : "−") + fmt(Math.abs(n));
}
function writeHash(s) {
	if (typeof window === "undefined") return;
	const parts = [`t=${s.t}`];
	if (s.mode !== "accept") parts.push(`mode=${s.mode}`);
	if (s.view !== "bar") parts.push(`view=${s.view}`);
	const next = `#${parts.join("&")}`;
	if (location.hash !== next) history.replaceState(null, "", next);
}
var useViz = create((set, get) => ({
	t: 20,
	mode: "accept",
	view: "bar",
	flowPaused: false,
	flowEpoch: 0,
	present: false,
	presentIdx: 0,
	kbdOpen: false,
	labOpen: false,
	manualT: false,
	setT: (t, fromScroll) => {
		const next = Math.round(clamp(t, 0, 30));
		const cur = get();
		if (next === cur.t) return;
		const patch = {
			t: next,
			...fromScroll ? {} : { manualT: true }
		};
		set(patch);
		writeHash({
			...cur,
			...patch
		});
	},
	setMode: (mode) => {
		set({ mode });
		writeHash({
			...get(),
			mode
		});
	},
	setView: (view) => {
		set({ view });
		writeHash({
			...get(),
			view
		});
	},
	setManualT: (manualT) => set({ manualT }),
	toggleFlowPause: (force) => set((s) => ({ flowPaused: force !== void 0 ? force : !s.flowPaused })),
	replayFlow: () => set((s) => ({
		flowEpoch: s.flowEpoch + 1,
		flowPaused: false
	})),
	togglePresent: (force) => set((s) => ({
		present: force !== void 0 ? force : !s.present,
		presentIdx: force === false ? s.presentIdx : s.presentIdx
	})),
	setPresentIdx: (presentIdx) => set({ presentIdx }),
	toggleKbd: (force) => set((s) => ({ kbdOpen: force !== void 0 ? force : !s.kbdOpen })),
	toggleLab: (force) => set((s) => ({ labOpen: force !== void 0 ? force : !s.labOpen })),
	hydrateFromHash: () => {
		if (typeof window === "undefined") return;
		const p = new URLSearchParams(location.hash.replace(/^#/, ""));
		const patch = {};
		if (p.has("t")) patch.t = Math.round(clamp(Number(p.get("t")) || 0, 0, 30));
		const mode = p.get("mode");
		if (mode === "accept" || mode === "tariff") patch.mode = mode;
		const view = p.get("view");
		if (view === "bar" || view === "curve") patch.view = view;
		if (Object.keys(patch).length) set(patch);
	}
}));
var SLIDES = ["top", ...SECTIONS.map((s) => s.id)];
function AppChrome() {
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [act, setAct] = (0, import_react.useState)("story");
	const [showTop, setShowTop] = (0, import_react.useState)(false);
	const present = useViz((s) => s.present);
	const presentIdx = useViz((s) => s.presentIdx);
	const labOpen = useViz((s) => s.labOpen);
	const kbdOpen = useViz((s) => s.kbdOpen);
	(0, import_react.useEffect)(() => {
		useViz.getState().hydrateFromHash();
		const onHash = () => useViz.getState().hydrateFromHash();
		addEventListener("hashchange", onHash);
		const onScroll = () => {
			const max = document.documentElement.scrollHeight - innerHeight;
			setProgress(max > 0 ? Math.min(1, scrollY / max) : 0);
			setScrolled(scrollY > 24);
			setShowTop(scrollY > 600);
		};
		addEventListener("scroll", onScroll, { passive: true });
		onScroll();
		const spy = new IntersectionObserver((es) => {
			es.forEach((e) => {
				if (e.isIntersecting) setAct(e.target.id);
			});
		}, { rootMargin: "-40% 0px -55% 0px" });
		SECTIONS.forEach((s) => {
			const el = document.getElementById(s.id);
			if (el) spy.observe(el);
		});
		const onKey = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			const st = useViz.getState();
			if (e.key === "?" || e.shiftKey && e.key === "/") {
				e.preventDefault();
				st.toggleKbd();
			} else if (e.key === "`" || e.key === "~") {
				e.preventDefault();
				st.toggleLab();
			} else if (e.key === "p" || e.key === "P") {
				if (st.kbdOpen) return;
				e.preventDefault();
				st.togglePresent();
			} else if (e.key === " ") {
				e.preventDefault();
				st.toggleFlowPause();
			} else if (e.key === "r" || e.key === "R") st.replayFlow();
			else if (e.key >= "1" && e.key <= "5") document.getElementById(SECTIONS[Number(e.key) - 1].id)?.scrollIntoView({ behavior: "smooth" });
			else if (e.key === "Escape") {
				st.togglePresent(false);
				st.toggleKbd(false);
				st.toggleLab(false);
			} else if (st.present && (e.key === "ArrowRight" || e.key === "ArrowLeft")) {
				const next = st.presentIdx + (e.key === "ArrowRight" ? 1 : -1);
				const idx = Math.max(0, Math.min(SLIDES.length - 1, next));
				st.setPresentIdx(idx);
				document.getElementById(SLIDES[idx])?.scrollIntoView({ behavior: "smooth" });
			}
		};
		addEventListener("keydown", onKey);
		return () => {
			removeEventListener("hashchange", onHash);
			removeEventListener("scroll", onScroll);
			removeEventListener("keydown", onKey);
			spy.disconnect();
		};
	}, []);
	(0, import_react.useEffect)(() => {
		document.body.classList.toggle("present", present);
		if (present) document.getElementById(SLIDES[presentIdx])?.scrollIntoView({ behavior: "smooth" });
	}, [present, presentIdx]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: "skip-link",
			href: "#story",
			children: "跳到主要内容"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pbar",
			style: { transform: `scaleX(${progress})` },
			"aria-hidden": true
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			"aria-label": "章节导航",
			className: cn("fixed inset-x-0 top-0 z-40 border-b transition-[background-color,border-color] duration-200", scrolled ? "border-line bg-bg/92 backdrop-blur-md" : "border-transparent bg-transparent"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-14 max-w-6xl items-center gap-1 px-4 sm:h-16 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "#top",
						className: "mr-3 flex items-center gap-2 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-6 place-items-center rounded-[6px] border border-line-strong text-[11px] text-muted",
							children: "IS"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "不公平竞争论"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden flex-1 items-center justify-center gap-1 md:flex",
						children: SECTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `#${s.id}`,
							className: cn("rounded-md px-3 py-2 text-sm", act === s.id ? "text-fg" : "text-muted hover:text-fg"),
							children: [
								s.no,
								" ",
								s.label
							]
						}, s.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1 md:hidden" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => useViz.getState().togglePresent(),
						className: "hidden sm:inline-flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presentation, {}), "演示"]
					})
				]
			})
		}),
		showTop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "回到顶部",
			onClick: () => scrollTo({
				top: 0,
				behavior: "smooth"
			}),
			className: "fab fixed right-4 bottom-24 z-30 grid size-11 place-items-center rounded-md border border-line bg-surface text-fg sm:right-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-4" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => useViz.getState().toggleLab(),
			className: "fab fixed right-4 bottom-6 z-30 inline-flex h-11 items-center gap-2 rounded-md border border-line bg-surface px-3 text-sm text-fg sm:right-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "size-4" }), "工程解剖"]
		}),
		labOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabPanel, {}),
		kbdOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "kbd-help fixed inset-0 z-50 grid place-items-center bg-bg/70 p-4",
			onClick: () => useViz.getState().toggleKbd(false),
			role: "dialog",
			"aria-label": "快捷键帮助",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-sm rounded-xl border border-line bg-surface p-5",
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center gap-2 font-display text-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, { className: "size-4" }), " 快捷键"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: KEYBOARD.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: row.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex gap-1",
							children: row.keys.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: k }, k))
						})]
					}, row.label))
				})]
			})
		}),
		present && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pres-hud fixed bottom-5 left-1/2 z-40 -translate-x-1/2 rounded-md border border-line bg-surface/95 px-4 py-2 text-xs text-muted",
			children: [
				"演示模式 · ",
				presentIdx + 1,
				" / ",
				SLIDES.length,
				" · ← → 翻页 · Esc 退出"
			]
		})
	] });
}
function LabPanel() {
	const t = useViz((s) => s.t);
	const mode = useViz((s) => s.mode);
	const view = useViz((s) => s.view);
	const hash = typeof window !== "undefined" ? location.hash || "（默认）" : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		role: "dialog",
		"aria-label": "工程解剖面板",
		className: "dev-panel fixed top-16 right-0 z-40 h-[calc(100dvh-4rem)] w-[min(100%,360px)] overflow-y-auto border-l border-line bg-surface p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg font-medium",
					children: "工程解剖"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-sm text-muted",
					onClick: () => useViz.getState().toggleLab(false),
					children: "关闭"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-xs text-dim",
				children: "本页实时展示自己的体检报告 · 按 ` 开关"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "运行时状态（URL 可分享）" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				k: "store.t / mode / view",
				v: `t=${t} · ${mode} · ${view}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				k: "状态镜像",
				v: hash
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "架构" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm leading-relaxed text-muted",
				children: [
					"纯函数模型 ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
						className: "font-mono text-xs",
						children: "calc(t)"
					}),
					" 是单一数据源，经 Zustand 发布给资金流、供需图、福利账、测验。状态写入 URL hash，刷新可还原。"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-1.5 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "model.ts 纯函数，11 组单测锁定课本口径" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "滚动叙事：scroll progress → 四相位绘制" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Canvas 标签防冲突：measureText + AABB" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "离屏暂停粒子与金币回路" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "DPR 封顶 2，ResizeObserver 重排" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "prefers-reduced-motion / skip link" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "设计令牌" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					["#8eb4c8", "is"],
					["#6fbfa3", "gain"],
					["#c4b48a", "nl"],
					["#d17a7a", "loss"],
					["#0b0c10", "bg"]
				].map(([hex, name]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1.5 text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
						className: "size-3 rounded-full border border-line",
						style: { background: hex }
					}), name]
				}, name))
			})
		]
	});
}
function H({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-5 mb-2 text-[11px] tracking-[0.14em] text-dim uppercase",
		children
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-3 border-b border-line py-2 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-dim",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "max-w-[55%] text-right font-mono text-xs font-medium break-all",
			children: v
		})]
	});
}
function CopyScript() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		onClick: async () => {
			try {
				await navigator.clipboard.writeText(SCRIPT);
			} catch {
				const ta = document.createElement("textarea");
				ta.value = SCRIPT;
				document.body.appendChild(ta);
				ta.select();
				document.execCommand("copy");
				ta.remove();
			}
			toast("逐字稿已复制");
		},
		children: "复制讲解逐字稿"
	});
}
function fitCanvas(cv, dprCap = 2) {
	const ctx = cv.getContext("2d");
	if (!ctx) return null;
	const r = cv.getBoundingClientRect();
	if (!r.width || !r.height) return null;
	const dpr = Math.min(window.devicePixelRatio || 1, dprCap);
	cv.width = Math.round(r.width * dpr);
	cv.height = Math.round(r.height * dpr);
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	return {
		ctx,
		w: r.width,
		h: r.height
	};
}
function roundRect(ctx, x, y, w, h, r) {
	const rr = Math.min(r, w / 2, h / 2);
	ctx.beginPath();
	ctx.moveTo(x + rr, y);
	ctx.arcTo(x + w, y, x + w, y + h, rr);
	ctx.arcTo(x + w, y + h, x, y + h, rr);
	ctx.arcTo(x, y + h, x, y, rr);
	ctx.arcTo(x, y, x + w, y, rr);
	ctx.closePath();
}
function downloadBlob(blob, name) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = name;
	document.body.appendChild(a);
	a.click();
	a.remove();
	setTimeout(() => URL.revokeObjectURL(url), 4e3);
}
var LW$1 = 1100;
var LH$1 = 520;
var LOOP = 10.5;
var STAGE = [
	0,
	2.2,
	4.4,
	6.6
];
var DUR = 1.7;
var WALL_X = 552;
var ACTORS = {
	taxpayer: {
		x: 150,
		y: 128,
		name: "NL 纳税人",
		c: "#c4b48a",
		kind: "people"
	},
	nlGov: {
		x: 150,
		y: 285,
		name: "NL 政府",
		c: "#c4b48a",
		kind: "gov"
	},
	nlFac: {
		x: 150,
		y: 442,
		name: "NL 纺织厂",
		c: "#c4b48a",
		kind: "factory"
	},
	isGov: {
		x: 950,
		y: 128,
		name: "IS 政府",
		c: "#8eb4c8",
		kind: "gov"
	},
	isCon: {
		x: 950,
		y: 285,
		name: "IS 消费者",
		c: "#8eb4c8",
		kind: "bag"
	},
	isFac: {
		x: 950,
		y: 442,
		name: "IS 纺织厂",
		c: "#8eb4c8",
		kind: "factory"
	}
};
function flows() {
	return [
		{
			a: "taxpayer",
			b: "nlGov",
			c1: {
				x: 105,
				y: 190
			},
			c2: {
				x: 105,
				y: 230
			},
			stage: 0,
			col: "#c4b48a",
			kind: "yen",
			tariff: "off"
		},
		{
			a: "nlGov",
			b: "nlFac",
			c1: {
				x: 195,
				y: 345
			},
			c2: {
				x: 195,
				y: 385
			},
			stage: 1,
			col: "#c4b48a",
			kind: "yen",
			tariff: "off"
		},
		{
			a: "nlFac",
			b: "isCon",
			c1: {
				x: 420,
				y: 470
			},
			c2: {
				x: 700,
				y: 320
			},
			stage: 2,
			col: "#6fbfa3",
			kind: "box",
			tariff: "wall"
		},
		{
			a: "isCon",
			b: "nlFac",
			c1: {
				x: 700,
				y: 480
			},
			c2: {
				x: 430,
				y: 520
			},
			stage: 3,
			col: "#8eb4c8",
			kind: "yen",
			tariff: "keep"
		},
		{
			a: "isCon",
			b: "isGov",
			c1: {
				x: 1005,
				y: 230
			},
			c2: {
				x: 1005,
				y: 190
			},
			stage: 1,
			col: "#d17a7a",
			kind: "yen",
			tariff: "only"
		}
	];
}
function bez(f, k) {
	const a = ACTORS[f.a];
	const b = ACTORS[f.b];
	const u = 1 - k;
	return {
		x: u * u * u * a.x + 3 * u * u * k * f.c1.x + 3 * u * k * k * f.c2.x + k * k * k * b.x,
		y: u * u * u * a.y + 3 * u * u * k * f.c1.y + 3 * u * k * k * f.c2.y + k * k * k * b.y
	};
}
function wallHitK(f) {
	for (let k = .05; k <= 1; k += .01) if (bez(f, k).x >= WALL_X) return k;
	return 1;
}
function icon(ctx, kind, x, y, col) {
	ctx.save();
	ctx.translate(x, y);
	ctx.strokeStyle = col;
	ctx.fillStyle = col;
	ctx.lineWidth = 1.6;
	ctx.lineJoin = "round";
	ctx.lineCap = "round";
	if (kind === "people") {
		ctx.beginPath();
		ctx.arc(-7, -6, 4.2, 0, Math.PI * 2);
		ctx.arc(7, -4, 3.4, 0, Math.PI * 2);
		ctx.stroke();
		ctx.beginPath();
		ctx.moveTo(-12, 10);
		ctx.quadraticCurveTo(-7, 2, -2, 10);
		ctx.moveTo(3, 10);
		ctx.quadraticCurveTo(7, 4, 12, 10);
		ctx.stroke();
	} else if (kind === "gov") {
		ctx.beginPath();
		ctx.moveTo(-11, 2);
		ctx.lineTo(0, -10);
		ctx.lineTo(11, 2);
		ctx.closePath();
		ctx.stroke();
		ctx.strokeRect(-8, 2, 16, 9);
	} else if (kind === "factory") {
		ctx.strokeRect(-12, -2, 24, 12);
		ctx.strokeRect(-8, -12, 5, 10);
		ctx.strokeRect(2, -10, 5, 8);
	} else {
		ctx.beginPath();
		ctx.moveTo(-8, -2);
		ctx.lineTo(-6, -8);
		ctx.lineTo(6, -8);
		ctx.lineTo(8, -2);
		ctx.closePath();
		ctx.stroke();
		ctx.strokeRect(-9, -2, 18, 11);
	}
	ctx.restore();
}
function FlowSim() {
	const cvRef = (0, import_react.useRef)(null);
	const mode = useViz((s) => s.mode);
	const setMode = useViz((s) => s.setMode);
	const paused = useViz((s) => s.flowPaused);
	const togglePause = useViz((s) => s.toggleFlowPause);
	const epoch = useViz((s) => s.flowEpoch);
	const replay = useViz((s) => s.replayFlow);
	const t = useViz((s) => s.t);
	const [step, setStep] = (0, import_react.useState)(0);
	const pausedRef = (0, import_react.useRef)(paused);
	pausedRef.current = paused;
	const exportPng = (0, import_react.useCallback)(() => {
		const cv = cvRef.current;
		if (!cv) return;
		cv.toBlob((b) => {
			if (b) downloadBlob(b, `资金流-t${t}.png`);
		}, "image/png");
	}, [t]);
	(0, import_react.useEffect)(() => {
		const cv = cvRef.current;
		if (!cv) return;
		let raf = 0;
		let visible = true;
		let t0 = performance.now();
		let pausedAt = 0;
		let wasPaused = pausedRef.current;
		let wallK = 0;
		let coins = [];
		let poofs = [];
		const pulses = {};
		const lastSpawn = [
			0,
			0,
			0,
			0,
			0
		];
		const tick = (now) => {
			if (!visible) return;
			const isPaused = pausedRef.current;
			if (isPaused && !wasPaused) pausedAt = now;
			if (!isPaused && wasPaused) t0 += now - pausedAt;
			wasPaused = isPaused;
			const fitted = fitCanvas(cv);
			if (!fitted) {
				raf = requestAnimationFrame(tick);
				return;
			}
			const { ctx, w, h } = fitted;
			const sx = (x) => x / LW$1 * w;
			const sy = (y) => y / LH$1 * h;
			const el = isPaused ? (pausedAt - t0) / 1e3 % LOOP : (now - t0) / 1e3 % LOOP;
			const fs = flows();
			const m = useViz.getState().mode;
			if (!isPaused) {
				fs.forEach((f, i) => {
					if (!(f.tariff === "only" ? m === "tariff" : f.tariff === "off" ? m !== "tariff" : true) || el < STAGE[f.stage]) return;
					if (el - lastSpawn[i] > .55 || el < lastSpawn[i]) {
						lastSpawn[i] = el;
						coins.push({
							f,
							born: el,
							k: 0,
							hit: false
						});
					}
				});
				coins = coins.filter((c) => {
					c.k = (el - c.born) / DUR;
					if (c.k < 0) return true;
					if (c.f.tariff === "wall" && m === "tariff") {
						const hk = wallHitK(c.f);
						if (c.k >= hk && !c.hit) {
							const p = bez(c.f, hk);
							poofs.push({
								x: p.x,
								y: p.y,
								t: now
							});
							return false;
						}
						return true;
					}
					if (c.k >= 1) {
						pulses[c.f.b] = now;
						return false;
					}
					return true;
				});
				poofs = poofs.filter((p) => now - p.t < 700);
			}
			const si = STAGE.reduce((acc, s, i) => el >= s ? i : acc, 0);
			setStep((prev) => prev === si ? prev : si);
			ctx.clearRect(0, 0, w, h);
			const placed = [];
			const chip = (text, cx, cy, col) => {
				ctx.font = "600 12px Source Sans 3, sans-serif";
				const tw = ctx.measureText(text).width + 16;
				const th = 22;
				for (const [dx, dy] of [
					[0, 34],
					[0, -38],
					[-46, 34],
					[46, 34],
					[0, 52],
					[-70, 0],
					[70, 0]
				]) {
					const x = cx + dx - tw / 2;
					const y = cy + dy - th / 2;
					const box = {
						x,
						y,
						w: tw,
						h: th
					};
					if (!placed.some((b) => !(box.x > b.x + b.w || box.x + box.w < b.x || box.y > b.y + b.h || box.y + box.h < b.y))) {
						placed.push(box);
						ctx.fillStyle = "rgba(11,12,16,.86)";
						ctx.strokeStyle = col;
						ctx.lineWidth = 1;
						roundRect(ctx, x, y, tw, th, 8);
						ctx.fill();
						ctx.stroke();
						ctx.fillStyle = "#eceae4";
						ctx.textAlign = "center";
						ctx.textBaseline = "middle";
						ctx.fillText(text, x + tw / 2, y + th / 2 + .4);
						return;
					}
				}
			};
			roundRect(ctx, sx(24), sy(60), sx(440) - sx(24), sy(492) - sy(60), 18);
			ctx.fillStyle = "rgba(196,180,138,.06)";
			ctx.fill();
			ctx.strokeStyle = "rgba(236,234,228,.12)";
			ctx.stroke();
			roundRect(ctx, sx(636), sy(60), sx(1076) - sx(636), sy(492) - sy(60), 18);
			ctx.fillStyle = "rgba(142,180,200,.06)";
			ctx.fill();
			ctx.stroke();
			ctx.font = "600 14px Source Sans 3, sans-serif";
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			ctx.fillStyle = "#c4b48a";
			ctx.fillText("Neighborland · 出口国", sx(244), sy(36));
			ctx.fillStyle = "#8eb4c8";
			ctx.fillText("Isoland · 进口国", sx(856), sy(36));
			ctx.strokeStyle = "rgba(142,180,200,.35)";
			ctx.lineWidth = 1.3;
			for (let r = 0; r < 3; r++) {
				ctx.beginPath();
				const yy = sy(140 + r * 120);
				for (let x = sx(478); x <= sx(622); x += 6) {
					const y = yy + Math.sin(x / 26 + now / 700 + r) * 5;
					x === sx(478) ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
				}
				ctx.stroke();
			}
			if (m === "tariff") {
				wallK = Math.min(1, wallK + .04);
				const wallH = (sy(492) - sy(60)) * wallK;
				const wx = sx(WALL_X);
				ctx.save();
				ctx.beginPath();
				ctx.rect(wx - 12, sy(60), 24, wallH);
				ctx.clip();
				for (let yy = sy(60); yy < sy(492); yy += 15) {
					ctx.fillStyle = yy / 15 % 2 < 1 ? "rgba(209,122,122,.5)" : "rgba(209,122,122,.28)";
					ctx.fillRect(wx - 10, yy, 20, 12);
				}
				ctx.restore();
				if (wallK > .9) chip("报复关税 t", wx, sy(300), "rgba(209,122,122,.7)");
			} else wallK = 0;
			fs.forEach((f) => {
				const on = f.tariff === "only" ? m === "tariff" : f.tariff === "off" ? m !== "tariff" : true;
				const started = el >= STAGE[f.stage];
				ctx.beginPath();
				ctx.moveTo(sx(ACTORS[f.a].x), sy(ACTORS[f.a].y));
				ctx.bezierCurveTo(sx(f.c1.x), sy(f.c1.y), sx(f.c2.x), sy(f.c2.y), sx(ACTORS[f.b].x), sy(ACTORS[f.b].y));
				ctx.setLineDash([7, 7]);
				ctx.lineDashOffset = -el * 18;
				ctx.strokeStyle = on && started ? f.col : "rgba(154,155,166,.28)";
				ctx.lineWidth = on && started ? 2.1 : 1.3;
				ctx.globalAlpha = on && started ? .9 : .55;
				ctx.stroke();
				ctx.globalAlpha = 1;
				ctx.setLineDash([]);
			});
			for (const c of coins) {
				const kk = c.f.tariff === "wall" && m === "tariff" ? Math.min(c.k, wallHitK(c.f)) : c.k;
				if (kk < 0 || kk > 1) continue;
				const p = bez(c.f, kk);
				const sc = kk < .08 ? kk / .08 : 1;
				if (c.f.kind === "yen") {
					ctx.beginPath();
					ctx.arc(sx(p.x), sy(p.y), 8.5 * sc, 0, Math.PI * 2);
					ctx.fillStyle = c.f.col;
					ctx.fill();
					ctx.fillStyle = "#0b0c10";
					ctx.font = `600 ${11 * sc}px IBM Plex Mono, monospace`;
					ctx.textAlign = "center";
					ctx.textBaseline = "middle";
					ctx.fillText("¥", sx(p.x), sy(p.y) + .5);
				} else {
					ctx.fillStyle = c.f.col;
					ctx.fillRect(sx(p.x) - 6 * sc, sy(p.y) - 5 * sc, 12 * sc, 10 * sc);
				}
			}
			for (const p of poofs) {
				const age = (now - p.t) / 700;
				ctx.globalAlpha = 1 - age;
				ctx.strokeStyle = "#d17a7a";
				ctx.lineWidth = 2;
				ctx.beginPath();
				ctx.arc(sx(p.x), sy(p.y), 6 + age * 16, 0, Math.PI * 2);
				ctx.stroke();
				ctx.globalAlpha = 1;
			}
			Object.entries(ACTORS).forEach(([key, a]) => {
				const k = sx(a.x);
				const ky = sy(a.y);
				const pulse = pulses[key];
				if (pulse) {
					const age = (now - pulse) / 650;
					if (age < 1) {
						ctx.beginPath();
						ctx.arc(k, ky, 32 + age * 16, 0, Math.PI * 2);
						ctx.strokeStyle = a.c;
						ctx.globalAlpha = (1 - age) * .7;
						ctx.lineWidth = 2;
						ctx.stroke();
						ctx.globalAlpha = 1;
					}
				}
				ctx.beginPath();
				ctx.arc(k, ky, 28, 0, Math.PI * 2);
				ctx.fillStyle = "rgba(255,255,255,.04)";
				ctx.fill();
				ctx.strokeStyle = a.c + "99";
				ctx.lineWidth = 1.4;
				ctx.stroke();
				icon(ctx, a.kind, k, ky, a.c);
				chip(a.name, k, ky, a.c + "88");
			});
			raf = requestAnimationFrame(tick);
		};
		t0 = performance.now();
		const io = new IntersectionObserver((es) => {
			visible = es.some((e) => e.isIntersecting);
			if (visible) raf = requestAnimationFrame(tick);
			else cancelAnimationFrame(raf);
		}, { threshold: .08 });
		io.observe(cv);
		raf = requestAnimationFrame(tick);
		return () => {
			cancelAnimationFrame(raf);
			io.disconnect();
		};
	}, [epoch]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-xl border border-line bg-surface",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 border-b border-line px-3 py-2.5 sm:px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex rounded-md border border-line bg-bg p-1",
						role: "group",
						"aria-label": "情景切换",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": mode === "accept",
							onClick: () => setMode("accept"),
							className: cn("h-9 rounded-[7px] px-3 text-sm font-medium", mode === "accept" ? "bg-surface-2 text-fg" : "text-muted"),
							children: "接受补贴"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": mode === "tariff",
							onClick: () => setMode("tariff"),
							className: cn("h-9 rounded-[7px] px-3 text-sm font-medium", mode === "tariff" ? "bg-surface-2 text-fg" : "text-muted"),
							children: "报复关税"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "iconSm",
						onClick: () => togglePause(),
						"aria-label": paused ? "继续" : "暂停",
						children: paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "iconSm",
						onClick: replay,
						"aria-label": "重播",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "iconSm",
						onClick: exportPng,
						"aria-label": "导出 PNG",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: cvRef,
				className: "block h-[320px] w-full sm:h-[420px] lg:h-[480px]",
				role: "img",
				"aria-label": "资金流向模拟：NL 纳税人缴税，政府补贴纺织厂，纺织品低价出口到 Isoland"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "grid grid-cols-2 gap-2 border-t border-line px-3 py-3 sm:grid-cols-4 sm:px-5",
				children: [
					"NL 纳税人出钱",
					"NL 政府补贴工厂",
					"低价出口到 IS",
					"IS 消费者付款"
				].map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: cn("flex items-center gap-2 text-sm", i < step ? "text-gain" : i === step ? "text-fg" : "text-dim"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("grid size-6 place-items-center rounded-full border text-[11px] font-medium", i < step ? "border-gain/50 bg-gain/15" : i === step ? "border-accent/50" : "border-line"),
						children: i + 1
					}), label]
				}, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-t border-line px-4 py-3 text-sm leading-relaxed text-muted",
				children: FLOW_CAPTIONS[mode]
			})
		]
	});
}
function useReducedMotion() {
	const [reduced, setReduced] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
		const apply = () => setReduced(mq.matches);
		apply();
		mq.addEventListener("change", apply);
		return () => mq.removeEventListener("change", apply);
	}, []);
	return reduced;
}
function HeroField() {
	const ref = (0, import_react.useRef)(null);
	const reduced = useReducedMotion();
	(0, import_react.useEffect)(() => {
		const cv = ref.current;
		if (!cv || reduced) return;
		let pts = [];
		let w = 0;
		let h = 0;
		let raf = 0;
		let visible = true;
		const seed = (n) => {
			pts = Array.from({ length: n }, () => ({
				x: Math.random() * w,
				y: Math.random() * h,
				vx: (Math.random() - .5) * .22,
				vy: (Math.random() - .5) * .22,
				r: 1 + Math.random() * 1.6,
				ph: Math.random() * Math.PI * 2,
				c: Math.random() < .55 ? "142,180,200" : "111,191,163"
			}));
		};
		const layout = () => {
			const fitted = fitCanvas(cv);
			if (!fitted) return;
			w = fitted.w;
			h = fitted.h;
			seed(Math.min(90, Math.max(28, Math.round(w * h / 16e3))));
		};
		const draw = (now) => {
			const fitted = fitCanvas(cv);
			if (!fitted) {
				raf = requestAnimationFrame(draw);
				return;
			}
			const { ctx } = fitted;
			if (fitted.w !== w || fitted.h !== h) {
				w = fitted.w;
				h = fitted.h;
			}
			ctx.clearRect(0, 0, w, h);
			const tt = now / 1e3;
			for (const p of pts) {
				p.x += p.vx;
				p.y += p.vy + Math.sin(tt + p.ph) * .1;
				if (p.x < -8) p.x = w + 8;
				if (p.x > w + 8) p.x = -8;
				if (p.y < -8) p.y = h + 8;
				if (p.y > h + 8) p.y = -8;
			}
			ctx.lineWidth = 1;
			for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
				const dx = pts[i].x - pts[j].x;
				const dy = pts[i].y - pts[j].y;
				const d2 = dx * dx + dy * dy;
				if (d2 < 11e3) {
					ctx.strokeStyle = `rgba(142,180,200,${((1 - Math.sqrt(d2) / 105) * .28).toFixed(3)})`;
					ctx.beginPath();
					ctx.moveTo(pts[i].x, pts[i].y);
					ctx.lineTo(pts[j].x, pts[j].y);
					ctx.stroke();
				}
			}
			for (const p of pts) {
				ctx.fillStyle = `rgba(${p.c},.85)`;
				ctx.beginPath();
				ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
				ctx.fill();
			}
			if (visible) raf = requestAnimationFrame(draw);
		};
		layout();
		const ro = new ResizeObserver(layout);
		ro.observe(cv);
		const io = new IntersectionObserver((es) => {
			visible = es.some((e) => e.isIntersecting);
			if (visible) raf = requestAnimationFrame(draw);
			else cancelAnimationFrame(raf);
		}, { threshold: .05 });
		io.observe(cv);
		raf = requestAnimationFrame(draw);
		return () => {
			cancelAnimationFrame(raf);
			ro.disconnect();
			io.disconnect();
		};
	}, [reduced]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		"aria-hidden": "true",
		className: "pointer-events-none absolute inset-0 h-full w-full"
	});
}
function QuizSection() {
	const [picked, setPicked] = (0, import_react.useState)([
		null,
		null,
		null
	]);
	const answered = picked.filter((p) => p !== null).length;
	const score = picked.reduce((n, p, i) => n + (p === QUIZ[i].ans ? 1 : 0), 0);
	const done = answered === QUIZ.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 flex items-center gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1.5",
					"aria-hidden": true,
					children: QUIZ.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: cn("block size-2 rounded-full", picked[i] !== null ? "bg-accent" : "bg-line-strong") }, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1 flex-1 overflow-hidden rounded-full bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-accent transition-[width] duration-250",
						style: { width: `${answered / QUIZ.length * 100}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "font-mono text-sm tabular-nums text-muted",
					children: [
						score,
						" / ",
						QUIZ.length
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children: QUIZ.map((item, qi) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-display text-lg font-medium",
						children: [
							qi + 1,
							". ",
							item.q
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid gap-2",
						children: item.opts.map((op, oi) => {
							const chosen = picked[qi];
							const locked = chosen !== null;
							const isAns = oi === item.ans;
							const isNo = locked && chosen === oi && !isAns;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: locked,
								onClick: () => setPicked((prev) => {
									const next = [...prev];
									next[qi] = oi;
									return next;
								}),
								className: cn("min-h-11 rounded-md border px-3 py-2.5 text-left text-sm", !locked && "border-line hover:border-line-strong hover:bg-surface-2", locked && isAns && "border-gain/50 bg-gain/12 text-gain", isNo && "border-loss/50 bg-loss/12 text-loss", locked && !isAns && !isNo && "border-line text-dim"),
								children: [
									"ABC"[oi],
									". ",
									op
								]
							}, op);
						})
					}),
					picked[qi] !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 border-t border-line pt-3 text-sm leading-relaxed text-muted",
						children: item.exp
					})
				]
			}, item.q))
		}),
		done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 rounded-xl border border-line bg-surface p-6 text-center",
			role: "status",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-3 grid size-12 place-items-center rounded-full border border-gain/40 bg-gain/10 text-gain",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl font-medium",
					children: score === 3 ? "满分。这页书你拿下了" : score === 2 ? "差一题，回看一下解析" : "建议重读第 01、02 节再来"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"得分 ",
						score,
						" / 3 · ",
						score === 3 ? "从资金流到福利账，整条链路都通了。" : "正确答案已经标出，解析就是第二次讲解。"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "mt-4",
					onClick: () => setPicked([
						null,
						null,
						null
					]),
					children: "重新作答"
				})
			]
		})
	] });
}
var LW = 620;
var LH = 470;
var X0 = 62;
var PW = 520;
var PH = 396;
var STEPS = [
	{
		b: "第 1 笔",
		d: "画出坐标轴与 D / S 曲线"
	},
	{
		b: "第 2 笔",
		d: "标出原世界价格 P₁ = 60"
	},
	{
		b: "第 3 笔",
		d: "补贴 t 把价格压到 P₂"
	},
	{
		b: "第 4 笔",
		d: "两块面积对比 → 净福利"
	}
];
function clamp01(v) {
	return Math.min(1, Math.max(0, v));
}
function SdChart() {
	const cvRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	const t = useViz((s) => s.t);
	useViz((s) => s.setT);
	const setManualT = useViz((s) => s.setManualT);
	const reduced = useReducedMotion();
	const [si, setSi] = (0, import_react.useState)(3);
	const m = calc(t);
	const draw = (0, import_react.useCallback)((ph) => {
		const cv = cvRef.current;
		if (!cv) return;
		const fitted = fitCanvas(cv);
		if (!fitted) return;
		const { ctx, w, h } = fitted;
		const mm = calc(useViz.getState().t);
		const X = (q) => (X0 + q / 130 * PW) / LW * w;
		const Y = (p) => (414 - p / 125 * PH) / LH * h;
		const line = (q1, p1, q2, p2, style, width = 1.5, dash) => {
			ctx.beginPath();
			ctx.moveTo(X(q1), Y(p1));
			ctx.lineTo(X(q2), Y(p2));
			ctx.strokeStyle = style;
			ctx.lineWidth = width;
			ctx.setLineDash(dash ?? []);
			ctx.stroke();
			ctx.setLineDash([]);
		};
		const poly = (pts, fill, alpha) => {
			ctx.globalAlpha = alpha;
			ctx.beginPath();
			pts.forEach(([q, p], i) => i ? ctx.lineTo(X(q), Y(p)) : ctx.moveTo(X(q), Y(p)));
			ctx.closePath();
			ctx.fillStyle = fill;
			ctx.fill();
			ctx.globalAlpha = 1;
		};
		const tag = (text, q, p, col, alpha) => {
			ctx.globalAlpha = alpha;
			ctx.font = "600 12px Source Sans 3, sans-serif";
			const tw = ctx.measureText(text).width + 16;
			const x = X(q) - tw / 2;
			const y = Y(p) - 11;
			ctx.fillStyle = "rgba(11,12,16,.88)";
			ctx.strokeStyle = col;
			roundRect(ctx, x, y, tw, 22, 8);
			ctx.fill();
			ctx.stroke();
			ctx.fillStyle = "#eceae4";
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			ctx.fillText(text, x + tw / 2, y + 11.5);
			ctx.globalAlpha = 1;
		};
		ctx.clearRect(0, 0, w, h);
		ctx.font = "11px Source Sans 3, sans-serif";
		ctx.fillStyle = "#6e707a";
		ctx.textAlign = "center";
		ctx.textBaseline = "top";
		for (let q = 0; q <= 120; q += 20) {
			line(q, 0, q, 125, "rgba(154,155,166,.08)", 1);
			ctx.fillText(String(q), X(q), Y(0) + 6);
		}
		ctx.textAlign = "right";
		ctx.textBaseline = "middle";
		for (let p = 0; p <= 120; p += 20) {
			line(0, p, 130, p, "rgba(154,155,166,.08)", 1);
			ctx.fillText(String(p), X(0) - 8, Y(p));
		}
		line(0, 0, 130, 0, "rgba(154,155,166,.4)", 1.5);
		line(0, 0, 0, 125, "rgba(154,155,166,.4)", 1.5);
		ctx.textAlign = "center";
		ctx.fillStyle = "#9a9ba6";
		ctx.fillText("Q（纺织品）", X(118), Y(0) + 20);
		ctx.save();
		ctx.translate(X(0) - 42, Y(66));
		ctx.rotate(-Math.PI / 2);
		ctx.fillText("P（元/件）", 0, 0);
		ctx.restore();
		if (ph.curve > 0) {
			ctx.save();
			ctx.beginPath();
			ctx.rect(0, 0, w * ph.curve, h);
			ctx.clip();
			line(0, 120, 120, 0, "#8eb4c8", 2.5);
			line(0, 20, 105, 125, "#d17a7a", 2.5);
			ctx.restore();
			if (ph.curve > .7) {
				ctx.font = "600 13px Source Sans 3, sans-serif";
				ctx.fillStyle = "#8eb4c8";
				ctx.textAlign = "left";
				ctx.fillText("D: Q = 120 − P", X(74), Y(52) - 14);
				ctx.fillStyle = "#d17a7a";
				ctx.fillText("S: Q = P − 20", X(74), Y(88) + 6);
			}
		}
		if (ph.p1 > 0) {
			ctx.globalAlpha = ph.p1;
			line(0, mm.p1, 130, mm.p1, "#9a9ba6", 1.5, [6, 5]);
			ctx.globalAlpha = 1;
			tag("P₁ = 60（原世界价）", 116, mm.p1, "rgba(154,155,166,.6)", ph.p1);
		}
		if (ph.p1 >= 1 && mm.t > 0) {
			line(0, mm.p2, 130, mm.p2, "#c4b48a", 1.7, [6, 5]);
			tag(`P₂ = ${mm.p2}（补贴后）`, 116, mm.p2, "rgba(196,180,138,.7)", 1);
			line(mm.qd1, mm.p1, mm.qd1, 0, "rgba(154,155,166,.3)", 1, [3, 4]);
			line(mm.qd2, mm.p2, mm.qd2, 0, "rgba(154,155,166,.3)", 1, [3, 4]);
			line(mm.qs1, mm.p1, mm.qs1, 0, "rgba(154,155,166,.3)", 1, [3, 4]);
		}
		if (ph.area > 0 && mm.t > 0) {
			const a = ph.area;
			poly([
				[mm.qd1, mm.p1],
				[mm.qd2, mm.p2],
				[mm.qd1, mm.p2]
			], "rgba(111,191,163,.34)", a);
			poly([
				[mm.qs1, mm.p1],
				[mm.qs1, mm.p2],
				[mm.qs2, mm.p2]
			], "rgba(209,122,122,.32)", a);
			tag(`消费者 +${fmt(mm.cs)}`, (mm.qd1 + mm.qd2) / 2 + 6, (mm.p1 + mm.p2) / 2, "rgba(111,191,163,.7)", a);
			tag(`生产者 −${fmt(Math.abs(mm.ps))}`, mm.qs1 / 2 + 4, (mm.p1 + mm.p2) / 2, "rgba(209,122,122,.7)", a);
			ctx.globalAlpha = a;
			ctx.font = "600 14px Source Sans 3, sans-serif";
			const txt = `Isoland 净福利 ${fmtSigned(mm.net)}`;
			const bw = ctx.measureText(txt).width + 26;
			const bx = X(66) - bw / 2;
			const by = Y(112);
			ctx.fillStyle = "rgba(111,191,163,.16)";
			ctx.strokeStyle = "#6fbfa3";
			roundRect(ctx, bx, by, bw, 30, 10);
			ctx.fill();
			ctx.stroke();
			ctx.fillStyle = "#b7e4d4";
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			ctx.fillText(txt, bx + bw / 2, by + 15.5);
			ctx.globalAlpha = 1;
		}
	}, []);
	const full = (0, import_react.useCallback)(() => draw({
		curve: 1,
		p1: 1,
		area: 1
	}), [draw]);
	const onScroll = (0, import_react.useCallback)(() => {
		const wrap = wrapRef.current;
		if (!wrap) return;
		if (!(window.matchMedia("(min-width: 921px)").matches && !useViz.getState().present) || reduced) {
			full();
			setSi(3);
			return;
		}
		const r = wrap.getBoundingClientRect();
		const total = r.height - innerHeight;
		if (total <= 0) return;
		const p = clamp01(-r.top / total);
		if (p <= 0) {
			setSi(0);
			useViz.getState().setManualT(false);
			draw({
				curve: 0,
				p1: 0,
				area: 0
			});
			return;
		}
		if (p >= 1) {
			setSi(3);
			useViz.getState().setManualT(false);
			full();
			return;
		}
		setSi(p < .24 ? 0 : p < .4 ? 1 : p < .76 ? 2 : 3);
		if (!useViz.getState().manualT && p > .4) {
			const tt = Math.round(20 * clamp01((p - .4) / .32));
			if (tt !== useViz.getState().t) {
				useViz.getState().setT(tt, true);
				return;
			}
		}
		draw({
			curve: clamp01(p / .22),
			p1: clamp01((p - .24) / .14),
			area: clamp01((p - .76) / .2)
		});
	}, [
		draw,
		full,
		reduced
	]);
	(0, import_react.useEffect)(() => {
		const on = () => requestAnimationFrame(onScroll);
		addEventListener("scroll", on, { passive: true });
		addEventListener("resize", on);
		on();
		const cv = cvRef.current;
		const ro = cv ? new ResizeObserver(on) : null;
		if (cv && ro) ro.observe(cv);
		const unsub = useViz.subscribe(() => on());
		return () => {
			removeEventListener("scroll", on);
			removeEventListener("resize", on);
			ro?.disconnect();
			unsub();
		};
	}, [onScroll]);
	const replay = () => {
		setManualT(true);
		if (reduced) {
			full();
			return;
		}
		const t0 = performance.now();
		const dur = 1400;
		const step = (now) => {
			const k = clamp01((now - t0) / dur);
			const e = 1 - Math.pow(1 - k, 2);
			draw({
				curve: clamp01(e / .35),
				p1: clamp01((e - .3) / .3),
				area: clamp01((e - .55) / .45)
			});
			if (k < 1) requestAnimationFrame(step);
		};
		requestAnimationFrame(step);
	};
	const exportPng = () => {
		const cv = cvRef.current;
		if (!cv) return;
		cv.toBlob((b) => {
			if (b) downloadBlob(b, `供需福利-t${t}.png`);
		}, "image/png");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrapRef,
		className: "sd-track relative lg:h-[240vh]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "lg:sticky lg:top-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-xl border border-line bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 border-b border-line px-3 py-2.5 sm:px-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid flex-1 grid-cols-2 gap-1 lg:grid-cols-4",
								children: STEPS.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: cn("rounded-md px-2 py-1.5 text-[12.5px] leading-tight", i === si ? "bg-surface-2 text-fg" : "text-dim"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: "mr-1 font-medium",
										children: s.b
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: s.d
									})]
								}, s.b))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "iconSm",
								onClick: replay,
								"aria-label": "重播绘制",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "iconSm",
								onClick: exportPng,
								"aria-label": "导出 PNG",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 p-3 lg:grid-cols-[1fr_240px] lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							ref: cvRef,
							className: "h-[280px] w-full sm:h-[380px] lg:h-[430px]",
							role: "img",
							"aria-label": "Isoland 纺织品市场供需图：需求 Q=120−P，供给 Q=P−20"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2 lg:grid-cols-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											k: "消费者剩余",
											v: `+${fmt(m.cs)}`,
											tone: "gain"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											k: "生产者剩余",
											v: `−${fmt(Math.abs(m.ps))}`,
											tone: "loss"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											k: "IS 净福利",
											v: fmtSigned(m.net),
											tone: "is"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TSlider, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-relaxed text-muted",
									children: "P₂ = 60 − t；补贴每加码 1 元，消费者多得、生产者多损，但赚的总比亏的多。"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden border-t border-line px-4 py-2 text-center text-xs text-dim lg:block",
						children: "继续滚动，驱动绘制"
					})
				]
			})
		})
	});
}
function Stat({ k, v, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-line bg-bg px-3 py-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[11px] tracking-wide text-dim",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("mt-0.5 font-mono text-lg tabular-nums", tone === "gain" ? "text-gain" : tone === "loss" ? "text-loss" : "text-is"),
			children: v
		})]
	});
}
function TSlider({ label }) {
	const t = useViz((s) => s.t);
	const setT = useViz((s) => s.setT);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "mb-2 flex items-center justify-between text-sm text-muted",
				children: [label ?? "补贴强度 t（元 / 件）", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
					className: "font-mono text-fg tabular-nums",
					children: ["t = ", t]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: 0,
				max: 30,
				step: 1,
				value: t,
				"aria-label": "补贴强度 t",
				onPointerDown: () => useViz.getState().setManualT(true),
				onChange: (e) => setT(Number(e.target.value)),
				className: "h-11 w-full cursor-pointer accent-accent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "mt-1 flex justify-between font-mono text-[11px] text-dim",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "0" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "10" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "20" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "30" })
				]
			})
		]
	});
}
var FILTERS = [
	{
		id: "all",
		label: "全部"
	},
	{
		id: "accept",
		label: "接受补贴"
	},
	{
		id: "tariff",
		label: "报复关税"
	},
	{
		id: "ban",
		label: "禁止进口"
	}
];
function WelfareBoard() {
	const t = useViz((s) => s.t);
	const view = useViz((s) => s.view);
	const setView = useViz((s) => s.setView);
	const s = scenarios(t);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const curve = (0, import_react.useMemo)(() => {
		const c = netCurve(31);
		return c.xs.map((x, i) => ({
			t: Math.round(x),
			accept: Math.round(c.accept[i]),
			tariff: Math.round(c.tariff[i])
		}));
	}, []);
	const barData = [
		{
			name: s.accept.name,
			消费者: s.accept.consumer,
			生产者: s.accept.producer,
			政府: s.accept.government,
			无谓损失: s.accept.dwl,
			净福利: s.accept.net
		},
		{
			name: s.tariff.name,
			消费者: s.tariff.consumer,
			生产者: s.tariff.producer,
			政府: s.tariff.government,
			无谓损失: s.tariff.dwl,
			净福利: s.tariff.net
		},
		{
			name: s.ban.name,
			消费者: s.ban.consumer,
			生产者: s.ban.producer,
			政府: s.ban.government,
			无谓损失: s.ban.dwl,
			净福利: s.ban.net
		}
	];
	const cards = [
		s.accept,
		s.tariff,
		s.ban
	];
	const axis = {
		stroke: "rgba(154,155,166,.35)",
		tick: {
			fill: "#9a9ba6",
			fontSize: 12
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				role: "tablist",
				"aria-label": "情景筛选",
				children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": filter === f.id,
					onClick: () => setFilter(f.id),
					className: cn("h-10 rounded-md border px-3 text-sm", filter === f.id ? "border-line-strong bg-surface-2 text-fg" : "border-line text-muted"),
					children: f.label
				}, f.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-3",
				children: cards.filter((c) => filter === "all" || c.key === filter).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl border border-line bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-lg font-medium",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: cn("font-mono text-sm tabular-nums", c.net > 0 ? "text-gain" : c.net < 0 ? "text-loss" : "text-muted"),
								children: ["净 ", fmtSigned(c.net)]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: [
								c.key === "accept" && `价格 P₁→P₂，消费者剩余 ${fmtSigned(c.consumer)}，生产者剩余 ${fmtSigned(c.producer)}。邻居替你掏钱，净赚。`,
								c.key === "tariff" && `关税 t 抵消补贴，价格回到 P₁。政府税收 ${fmtSigned(c.government)}，无谓损失 ${fmtSigned(c.dwl)}，白忙一场。`,
								c.key === "ban" && "回到自给自足 P=70：工厂 +450，消费者 −550。唯一确定变穷的选择。"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniBars, { c })
					]
				}, c.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-surface p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-lg font-medium",
								children: "福利账 · 全局联动"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex rounded-md border border-line bg-bg p-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setView("bar"),
									className: cn("h-9 rounded-[7px] px-3 text-sm", view === "bar" ? "bg-surface-2 text-fg" : "text-muted"),
									children: "三种选择对比"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setView("curve"),
									className: cn("h-9 rounded-[7px] px-3 text-sm", view === "curve" ? "bg-surface-2 text-fg" : "text-muted"),
									children: "强度—净福利曲线"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-[280px] w-full sm:h-[320px]",
						children: view === "bar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: barData,
							margin: {
								top: 8,
								right: 8,
								left: 0,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									stroke: "rgba(154,155,166,.1)",
									vertical: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "name",
									...axis
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { ...axis }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									background: "#13151c",
									border: "1px solid rgba(236,234,228,.12)",
									borderRadius: 12,
									color: "#eceae4"
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "消费者",
									stackId: "w",
									fill: "#8eb4c8",
									radius: [
										0,
										0,
										0,
										0
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "生产者",
									stackId: "w",
									fill: "#d17a7a"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "政府",
									stackId: "w",
									fill: "#c4b48a"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "无谓损失",
									stackId: "w",
									fill: "#6e707a",
									radius: [
										6,
										6,
										0,
										0
									]
								})
							]
						}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
							data: curve,
							margin: {
								top: 8,
								right: 12,
								left: 0,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, { stroke: "rgba(154,155,166,.1)" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "t",
									...axis
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { ...axis }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									background: "#13151c",
									border: "1px solid rgba(236,234,228,.12)",
									borderRadius: 12,
									color: "#eceae4"
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferenceLine, {
									x: t,
									stroke: "#c4b48a",
									strokeDasharray: "4 4"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: "accept",
									name: "接受补贴",
									stroke: "#6fbfa3",
									strokeWidth: 2.4,
									dot: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: "tariff",
									name: "报复关税",
									stroke: "#8eb4c8",
									strokeWidth: 2,
									strokeDasharray: "6 4",
									dot: false
								})
							]
						}) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TSlider, { label: "补贴强度 t（与第 02 节同一状态）" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid gap-2 sm:grid-cols-3",
						children: [
							[
								"接受补贴",
								s.accept.net,
								"text-gain"
							],
							[
								"报复关税",
								s.tariff.net,
								"text-price"
							],
							[
								"禁止进口",
								s.ban.net,
								"text-loss"
							]
						].map(([k, v, c]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-md border border-line bg-bg px-3 py-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: k
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: cn("font-mono tabular-nums", c),
								children: fmtSigned(v)
							})]
						}, k))
					})
				]
			})
		]
	});
}
function MiniBars({ c }) {
	const rows = [
		[
			"消费者",
			c.consumer,
			"bg-is"
		],
		[
			"生产者",
			c.producer,
			"bg-loss"
		],
		[
			"政府",
			c.government,
			"bg-nl"
		],
		[
			"无谓损失",
			c.dwl,
			"bg-dim"
		]
	];
	const max = Math.max(1, ...rows.map(([, v]) => Math.abs(v)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-4 space-y-2",
		children: rows.map(([k, v, bg]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "grid grid-cols-[64px_1fr_56px] items-center gap-2 text-xs",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-dim",
					children: k
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1.5 overflow-hidden rounded-full bg-bg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("h-full rounded-full", bg),
						style: { width: `${Math.abs(v) / max * 100}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-right font-mono tabular-nums text-muted",
					children: fmtSigned(v)
				})
			]
		}, k))
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grain",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppChrome, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Story, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartSec, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelfareSec, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizSec, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Finale, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line py-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-2 px-4 text-sm text-dim sm:flex-row sm:items-center sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "不公平竞争论 · Isoland × Neighborland" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "·"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "曼昆《经济学原理》第 9 章 · 按 ? 查看快捷键" })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "bottom-center",
				toastOptions: { style: {
					background: "#13151c",
					border: "1px solid rgba(236,234,228,.12)",
					color: "#eceae4"
				} }
			})
		]
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		id: "top",
		className: "relative flex min-h-[100dvh] items-end overflow-hidden pb-16 pt-24 sm:items-center sm:pb-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroField, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 mx-auto w-full max-w-6xl px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.18em] text-muted uppercase",
					children: "曼昆《经济学原理》第 9 章 · 国际贸易 · 对应课本 P177 图"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 max-w-4xl font-display text-4xl font-medium leading-[1.08] tracking-[-0.04em] sm:text-5xl md:text-[3.4rem]",
					children: "不公平竞争论"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-2xl text-base leading-relaxed text-muted sm:text-lg",
					children: "Neighborland 政府对纺织品出口补贴，Isoland 的工厂叫苦连天。报复关税？禁止进口？还是说声谢谢？用一页图解把福利账算清楚。"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 flex flex-wrap gap-2",
					children: [
						"滚动叙事",
						"全局状态联动",
						"URL 可分享",
						"模型单测覆盖"
					].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full border border-line px-3 py-1 text-xs text-muted",
						children: c
					}, c))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#story",
							children: "开始图解"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => useViz.getState().togglePresent(true),
						children: ["演示模式", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", { children: "P" })]
					})]
				})
			]
		})]
	});
}
function Wrap({ id, no, title, sub, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id,
		className: "scroll-mt-20 border-t border-line py-16 sm:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-2xl font-medium sm:text-3xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mr-3 font-sans text-sm tracking-[0.16em] text-dim",
						children: no
					}), title]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 mb-8 max-w-2xl text-muted",
					children: sub
				}),
				children
			]
		})
	});
}
function Story() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Wrap, {
		id: "story",
		no: "01",
		title: "一个故事：补贴是怎么流到你手里的",
		sub: "Neighborland（NL）政府宣布：纺织品每出口一件，补贴 t 元。钱从哪来，又到哪去？切换「报复关税」看 Isoland 反击后的资金流。",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowSim, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-3 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border border-line bg-surface p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg text-nl",
					children: "Neighborland · 出口国"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-fg",
							children: "纳税人"
						}), "：补贴的钱，从他们的税收里出"] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-fg",
							children: "政府"
						}), "：每件出口纺织品补贴 t 元"] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-fg",
							children: "纺织厂"
						}), "：拿到补贴，敢把价格压到 P₂ = 60 − t"] })
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border border-line bg-surface p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg text-is",
					children: "Isoland · 进口国"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-fg",
							children: "消费者"
						}), "：同样的布，更便宜——消费者剩余增加"] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-fg",
							children: "纺织厂"
						}), "：价格被压低，份额被挤——生产者剩余减少"] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-fg",
							children: "政府"
						}), "：面对「不公平竞争」的指责，要表态"] })
					]
				})]
			})]
		})]
	});
}
function ChartSec() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrap, {
		id: "chart",
		no: "02",
		title: "画图讲：补贴的福利分析",
		sub: "往下滚动，看图被一笔一笔画出来；随时拖滑杆接管，所有图表和数字全局联动。",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SdChart, {})
	});
}
function WelfareSec() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrap, {
		id: "welfare",
		no: "03",
		title: "三种选择：摆在 IS 政府面前的路",
		sub: "同样的补贴强度，三种回应，三笔完全不同的账。",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelfareBoard, {})
	});
}
function QuizSec() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrap, {
		id: "quiz",
		no: "04",
		title: "测一测：这页书你拿下了吗",
		sub: "三道题，答完出结算。答错别怕，解析就是第二次讲解。",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizSection, {})
	});
}
function Finale() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Wrap, {
		id: "final",
		no: "05",
		title: "结论：谢谢你的「不公平竞争」",
		sub: "当邻居执意要补贴你买东西时，最好的回应不是报复，而是说声谢谢。",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
				className: "rounded-xl border border-line bg-surface p-6 font-display text-xl leading-snug sm:p-8 sm:text-2xl",
				children: ["当邻居执意要补贴你买东西时，最好的回应不是报复，而是说声谢谢。所谓「不公平竞争」，账算到最后，是对方纳税人在为你的消费者买单。", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: "mt-4 font-sans text-sm text-dim",
					children: "—— 曼昆《经济学原理》第 9 章 · 出口补贴的福利分析"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-line bg-surface p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-lg",
							children: "账要算总账"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: "消费者 +1,400、生产者 −600，净福利 +800。分配会痛，但总量在涨。"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-line bg-surface p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-lg",
							children: "报复最贵"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: "报复关税把价格抬回去：政府收的 400，恰好等于无谓损失 400，净效应归零。"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-line bg-surface p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-lg",
							children: "禁止最亏"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: "禁止进口回到自给自足：工厂赚的 450，抵不上消费者亏的 550，净 −100。"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-sm text-dim",
				children: "注：本页按课本局部均衡模型展开，暂不考虑报复升级、产业动态与政治经济学约束——那是第 10 章之后的故事。"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyScript, {})
			})
		]
	});
}
//#endregion
export { Home as component };
